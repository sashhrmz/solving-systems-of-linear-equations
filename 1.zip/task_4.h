//
// Created by sasha on 04/11/19.
//

#ifndef LABARATORNAYA1_TASK_4_H
#define LABARATORNAYA1_TASK_4_H

#include "matrix.h"

void Task_4(std::vector<std::vector<double>>& matrix, std::vector<double>& values) {
    for(size_t i = 0; i < matrix.size() - 1; ++i) {
        if(matrix[i][i] < matrix[i + 1][i]) {
            std::swap(matrix[i][i], matrix[i + 1][i]);
            std::swap(values[i], values[i + 1]);
        }
        values[i] /= matrix[i][i];
        matrix[i][i + 1] /= matrix[i][i];
        matrix[i + 1][i + 1] -= matrix[i][i + 1] * matrix[i + 1][i];
        values[i + 1] -= values[i] * matrix[i + 1][i];
    }
    values[matrix.size() - 1] /= matrix[matrix.size() - 1][matrix.size() - 1];
    for(size_t i = matrix.size() - 2; i >= 0; --i) {
        values[i] -= values[i + 1] * matrix[i][i + 1];
    }
}

#endif //LABARATORNAYA1_TASK_4_H
