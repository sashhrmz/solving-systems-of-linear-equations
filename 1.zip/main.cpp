#include "test.h"

int main() {
    Test test;
    test.TestForthTask();

    return 0;
}