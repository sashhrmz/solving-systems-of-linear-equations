#include "test.h"

int main() {
    Test test;
    test.TestFirstTask();
    return 0;
}