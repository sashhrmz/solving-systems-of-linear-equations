#include "test.h"

int main() {
    Test test;
    test.TestFirstTask(false, true, false);
    test.TestSecondTask(false);
    //test.TestThirdTask();
    return 0;
}