//
// Created by sasha on 22/10/19.
//

#ifndef LABARATORNAYA1_TEST_H
#define LABARATORNAYA1_TEST_H

#include <map>
#include "task_1.h"
#include "task_2.h"

class Test {
public:
    std::map<size_t, double> TestFirstTask() {
        std::map<size_t, double> work_time;
        for(size_t i = 10; i < 2020; i += 500) {
            std::vector<std::vector<double>> matrix_vector;
            double temp;
            for(size_t j = 0; j < i; ++j) {
                matrix_vector.emplace_back();
                for(size_t k = 0; k < std::min((j + 2), i); ++k) {
                    temp = rand() + 1;
                    matrix_vector[j].push_back(temp);
                }
            }
            double start_time = clock(); // начальное время

            Task_1(matrix_vector);

            double end_time = clock(); // конечное время
            double search_time = (end_time - start_time) / CLOCKS_PER_SEC; // искомое время
            work_time.insert({i, search_time});
            std::cout << i << " - " << search_time << std::endl;
        }
    }

    void TestSecondTask() {
        std::vector<std::vector<double>> value = {{3}, {-3}, {-5}, {5}};

        std::vector<std::vector<double>> matrix = {{-3, 4, 2, -3, 2, 3, 4, 3},
                                                   {-3, 4, -1, 1, -4, -5, -1, 0},
                                                   {-6, 8, 1, -1, 1, 3, -3, -5},
                                                   {-12, 16, 2, -3, 4, -2, -3, 4},
                                                   {-24, 32, 4, -6, 3, -3, -1, -2},
                                                   {-48, 64, 8, -12, 6, -4, 3, -3},
                                                   {-96, 1280, 16, -24, 12, -8, -1, 4},
                                                   {2, -1, -3, -4, -5, 4, 1, -5}};
        double start_time = clock(); // начальное время

        Task_2(matrix, value);

        double end_time = clock(); // конечное время
        double search_time = (end_time - start_time) / CLOCKS_PER_SEC; // искомое время
        std::cout << search_time;
    }
};

#endif //LABARATORNAYA1_TEST_H
